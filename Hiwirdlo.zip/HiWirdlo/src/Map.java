import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Composite;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;

//	map class
/*

	contains the map class and item class
	
*/
public class Map 
{
	private int ticktime;
	private int fulltick;
	private int maxticktime;
	private float tick;
	public int length = 21;
	public int length_z = 21;
	private int item_width = 32;
	public int screen_px = 200;
	public int screen_py = 200;
	
	//public Camera camera1 = new Camera();
	public Player player;
	public Player player1;
	Item[][][] array;
	
	private class Direction
	{
		public int xaxis;
		public int yaxis;
		public int zaxis;
	}
	
	private class Item
	{
		public int contain;
		public boolean player;
		public Bomb bomb;
		public boolean hasbomb;
		public int planted;
		public Item()
		{
			contain = 0;
			planted = 0;
			hasbomb = false;
			//player = false;
		}
		
	}

	
	
	public class Player
	{
		public int x;
		public int y;
		public int z;
		public int size;
		public int direction;
		public float speedtick;
		public int speed;
		public float lastspeedtick;
		public int health;
		private boolean damage;
		private boolean move;
		public Camera camera;
		private int drawPadding;
		public boolean alive = true;
		
		public Player(int _x, int _y,int _z)
		{
			x = _x;
			y = _y;
			z = _y; 
			size = 1;
			speed = 1;
			direction = 0;
			health = 3;
			damage = false;
			move = false;
			lastspeedtick = 0;
			speedtick = 0.2f;
			drawPadding = 800;
			camera = new Camera(drawPadding);
		}
		
		public Player()
		{
			x = 1;
			y = 1;
			z = 1; 
			size = 1;
			speed = 1;
			direction = 0;
			health = 3;
			damage = false;
			move = false;
			lastspeedtick = 0;
			speedtick = 0.2f;
			drawPadding = 0;
			camera = new Camera(drawPadding);
		}
		
		private boolean collide(int direction,int speed, int id)
		{
			switch(direction)
			{
				case 0:
					if (array[x][y][z].contain == id)
					{
						return true;
					}
				break;
			
				case 2: //left y
					if (y-speed < 0 || array[x][y-speed][z].contain == id)
					{
						return true;
					}
				break;
				
				case 4: //right y
					if (y+speed > length-1 || array[x][y+speed][z].contain == id)
					{
						return true;
					}
				break;
								
				case 3: //left x
					if (x-speed < 0 || array[x-speed][y][z].contain == id)
					{
						return true;
					}
				break;
				
				case 1: //right x
					if (x+speed > length-1 || array[x+speed][y][z].contain == id)
					{
						return true;
					}
				break;
				
				case 5: //left z
					if (z-speed < 0 || array[x][y][z-speed].contain == id)
					{
						return true;
					}
				break;
				
				case 6: //right z
					if (z+speed > length_z-1 || array[x][y][z+speed].contain == id)
					{
						return true;
					}
				break;
			}	
			return false;
		}
		
		public void collision()
		{
			if (collide(0,1,3) == true || collide(0,1,7) == true || collide(0,1,6) == true)
			{
				if (damage == false && health > 0)
				{
					health -= 1;
				}
				
				damage = true;
			}
			else
			{
				damage = false;
			}
			
			if (health == 0)
			{
				camera.player = null;
				alive = false;
			}
		}
		
		public void movinglistener(int key,boolean follow)
		{
			//direction = 0;
			
			switch(key)
			{
				case KeyEvent.VK_W:
					direction = camera.calculateRelativeAngle(2);
				break;
				
				case KeyEvent.VK_S:
					direction = camera.calculateRelativeAngle(4);
				break;
								
				case KeyEvent.VK_A:
					direction = camera.calculateRelativeAngle(3);
				break;
				
				case KeyEvent.VK_D:
					direction = camera.calculateRelativeAngle(1);
				break;
				
				case KeyEvent.VK_Q:
					direction = camera.calculateRelativeAngle(5);
				break;
				
				case KeyEvent.VK_E:
					direction = camera.calculateRelativeAngle(6);
				break;
				
				case KeyEvent.VK_UP:
					camera.angle += 1;
					if (follow == true)
					{
						camera.follow(this);
					}
					direction = 0;
				break;
				
				case KeyEvent.VK_DOWN:
					camera.angle -= 1;
					if (follow == true)
					{
						camera.follow(this);
					}
					direction = 0;
				break;
				
				case KeyEvent.VK_SPACE:
					placebomb();
					direction = 0;
				break;
			}	
			if (direction > 0 && collide(direction,1,1) == false && collide(direction,1,8) == false && collide(direction,1,2) == false) //speed kell majd k�s�bbiekben
			{
				movement(direction,follow);
			}
		}

		public void move(boolean follow)
		{
			if (move == true)
			{
				if (direction > 0 && collide(direction,1,1) == false && collide(direction,1,8) == false && collide(direction,1,2) == false) //speed kell majd k�s�bbiekben
				{
					if (tick > lastspeedtick+speedtick)
					{
					movement(direction,follow);
					lastspeedtick = tick;
					}
				}
				else
				{
					move = false;
				}
			}
		}
		
		public void moving(int key,boolean released,boolean follow)
		{
			//direction = 0;
			if (released == true)
			{
				move = false;
			}
			else
			{
				switch(key)
				{
					case 0:
						direction = camera.calculateRelativeAngle(2);
						move = true;
					break;
					
					case 1:
						direction = camera.calculateRelativeAngle(4);
						move = true;
					break;
									
					case 2:
						direction = camera.calculateRelativeAngle(3);
						move = true;
					break;
					
					case 3:
						direction = camera.calculateRelativeAngle(1);
						move = true;
					break;
					
					case 5:
						direction = camera.calculateRelativeAngle(5);
						move = true;
					break;
					
					case 4:
						direction = camera.calculateRelativeAngle(6);
						move = true;
					break;
					
					case 6:
						if (camera.angle < 2)
						{
							camera.angle += 1;
							
						}
						else
						{
							camera.angle = 0;
						}
						
						if (follow == true)
						{
							camera.follow(this);
						}
						direction = 0;
					break;
					
					case 7:
						if (camera.angle > 0)
						{
							camera.angle -= 1;
						}
						else
						{
							camera.angle = 2;
						}
						
						if (follow == true)
						{
							camera.follow(this);
						}
						direction = 0;
					break;
					
					case 8:
						placebomb();
						direction = 0;
					break;
					
				}	
			}
			
		}
		
		private void movement(int direction,boolean follow)
		{
			
			switch(direction)
			{
				case 2:
					
					if (y-1 > 0)
					{
					y -= 1;	
					}
					else
					{
					y = 0;
					}
					
				break;
				
				case 4:
					
					if (y+1 < length)
					{				
					y += 1;	
					}		
					else
					{
					y = length;
					}
					
				break;
								
				case 3:
					
					if (x-1 > 0)
					{
					x -= 1;	
					}
					else
					{
					x = 0;
					}
					
				break;
				
				case 1:
					
					if (x+1 < length)
					{
					x += 1;	
					}
					else
					{
					x = length;
					}
					
				break;
				
				case 5:
					
					if (z-1 > 0)
					{
					z -= 1;	
					}
					else
					{
					z = 0;
					}
					
				break;
				
				case 6:
					
					if (z+1 < length_z-1)
					{
					z += 1;	
					}
					else
					{
					z = length_z-1;
					}
					
				break;
			}	
			if (follow == true)
			{
				camera.follow(this);
			}
		}
		
		private void dig(int direction)
		{
			Item item = new Item();
			item.contain = 0;
			switch(direction)
			{
				case 2:
					array[x][y-1][z] = item;
					
				break;
				
				case 4:
					array[x][y+1][z] = item;
				break;
								
				case 3:
					array[x-1][y][z] = item;
				break;
				
				case 1:
					array[x+1][y][z] = item;
				break;
			}	
			System.out.println("break");
		}
		
		private void placebomb()
		{
			Item item = new Item();
			Bomb bomb = new Bomb();
			bomb.x = x;
			bomb.y = y;
			bomb.z = z;
			item.contain = 0;
			item.bomb = bomb;
			item.hasbomb = true;
			array[x][y][z] = item;
			System.out.println("bomb");
		}
		
		public void draw(Graphics g, Texture SpriteSheet)
		{
			if (alive == true)
			{
				double item_width_c = Math.sqrt(Math.pow(item_width,2)+Math.pow(item_width,2))+2;
				
				int x_s = screen_px+(x-(camera.x-camera.x_rs))*(int)item_width_c;
				int wh_s = (int)item_width_c-item_width;
				int padding_z = ((int)item_width_c*(z-(camera.z-camera.z_rs)));
				int y_s = 0;
				
				switch (camera.angle)
				{
					case 0:
						x_s = screen_px+(x-(camera.x-camera.x_rs))*(int)item_width_c;
						y_s = screen_py+(y-(camera.y-camera.y_rs))*(int)item_width_c;
					break;
				
					case 1:
						x_s = screen_px+(x-(camera.x-camera.x_rs))*(int)item_width_c;
						y_s = screen_py+(z-(camera.z-camera.z_rs))*(int)item_width_c;
					break;
						
					case 2:
						x_s = screen_px+(z-(camera.z-camera.z_rs))*(int)item_width_c;
						y_s = screen_py+(y-(camera.y-camera.y_rs))*(int)item_width_c;
					break;
						
				}
				
				drawItemTexture(g,x_s+drawPadding,y_s, 4, SpriteSheet,1f);
			}
		}
	}

	private class Bomb
	{
		public int x;
		public int y;
		public int z;
		private int size;
		private int created;
		private int explosiontime;
		private int firetime;
		private int explosionsize;
		private int[] explosionindex = new int[6];
		private boolean explosion;
		public Bomb()
		{
			x = 0;
			y = 0;
			z = 0; 
			size = 1;
			created = fulltick;
			explosiontime = 5;
			explosionsize = 3;
			explosionindex[0] = 0;
			explosionindex[1] = 0;
			explosionindex[2] = 0;
			explosionindex[3] = 0;
			explosionindex[4] = 0;
			explosionindex[5] = 0;
			firetime = 3;
			explosion = true;
		}
		
		private void explode()
		{
			System.out.println(String.valueOf(fulltick-created));
			if (fulltick-created >= explosiontime)
			{
				while (explosionindex[1] > -1 || explosionindex[4] > -1 || explosionindex[5] > -1 || explosionindex[2] > -1 || explosionindex[3] > -1 || explosionindex[0] > -1)
				{
					if (explosion == true)
					{
						if (explosionindex[0] == 0)
						{
							if (collide(0,0,0) == 1)
							{
								setExplosion(0,0);
							}
							else
							{
								System.out.println("systemTick - bomb disarmed");
								array[x][y][z].hasbomb = false;
							}
							explosionindex[0] = 1;
							explosionindex[1] = 1;
							explosionindex[2] = 1;
							explosionindex[3] = 1;
							explosionindex[4] = 1;
							explosionindex[5] = 1;
						}
						else
						{
							for (int i = 0; i < 6; i++)
							{
								
								if (explosionindex[i] != -1 && explosionindex[i] <= explosionsize)
								{
									if (collide(i+1,explosionindex[i],0) == 1)
									{
									setExplosion(i+1,explosionindex[i]);
									}
									else
									{
										if (collide(i+1,explosionindex[i],2) == 1)
										{
										setExplosion(i+1,explosionindex[i]);
										}
										explosionindex[i] = -1;
									}
								}
								else
								{
									explosionindex[i] = -1;
								}
							}
							for (int i = 0; i < 6; i++)
							{
								if (explosionindex[i] != -1)
								{
								explosionindex[i]+= 1;
								}
							}
						}
					}
				}
				if (explosion == true)
				{
				created = fulltick;
				}
				
				explosion = false;
			}
			
			
			if (explosion == false && fulltick-created >= firetime)
			{
				explosionindex[0] = 0;
				explosionindex[1] = 0;
				explosionindex[2] = 0;
				explosionindex[3] = 0;
				explosionindex[4] = 0;
				explosionindex[5] = 0;
				while (explosionindex[1] > -1 || explosionindex[4] > -1 || explosionindex[5] > -1 || explosionindex[2] > -1 || explosionindex[3] > -1 || explosionindex[0] > -1)
				{
					if (explosionindex[0] == 0)
					{
						if (collide(0,0,3) == 1 || collide(0,0,6) == 1 || collide(0,0,3) == 7)
						{
							setClear(0,0);
						}
						else
						{
							setClear(0,0);
							System.out.println("systemTick - bomb disarmed");
							array[x][y][z].hasbomb = false;
						}
						explosionindex[0] = 1;
						explosionindex[1] = 1;
						explosionindex[2] = 1;
						explosionindex[3] = 1;
						explosionindex[4] = 1;
						explosionindex[5] = 1;
					}
					else
					{
						for (int i = 0; i < 6; i++)
						{
							if (explosionindex[i] != -1 && (collide(i+1,explosionindex[i],3) == 1 || collide(i+1,explosionindex[i],6) == 1 || collide(i+1,explosionindex[i],7) == 1) && explosionindex[i] <= explosionsize)
							{
								setClear(i+1,explosionindex[i]);
							}
							else
							{
								explosionindex[i] = -1;
								
							}
						}
						for (int i = 0; i < 6; i++)
						{
							if (explosionindex[i] != -1)
							{
							explosionindex[i]+= 1;
							}
						}
					}
				}
				System.out.println("systemTick - bomb disarmed");
				array[x][y][z].hasbomb = false;
			}
		}
		
		private void setExplosion (int direction, int speed)
		{
			switch(direction)
			{
				case 2: //up
					array[x][y-speed][z].contain = 3;
					array[x][y-speed][z].planted = created;
				break;
				
				case 4: //down 
					array[x][y+speed][z].contain = 3;
					array[x][y+speed][z].planted = created;
				break;
								
				case 3: //left
					array[x-speed][y][z].contain = 6;
					array[x-speed][y][z].planted = created;
				break;
				
				case 1: //right
					array[x+speed][y][z].contain = 6;
					array[x+speed][y][z].planted = created;
				break;
				
				case 5: //z up
					array[x][y][z-speed].contain = 6;
					array[x][y][z-speed].planted = created;
				break;
				
				case 6: //z down 
					array[x][y][z+speed].contain = 6;
					array[x][y][z+speed].planted = created;
				break;
				
				case 0: //none
					array[x][y][z].contain = 7;
					array[x][y][z].planted = created;
				break;
			}	
		}
		
		private void setClear (int direction, int speed)
		{
			switch(direction)
			{
				case 2: //up
					array[x][y-speed][z].contain = 0;
				break;
				
				case 4: //down 
					array[x][y+speed][z].contain = 0;
				break;
								
				case 3: //left
					array[x-speed][y][z].contain = 0;
				break;
				
				case 1: //right
					array[x+speed][y][z].contain = 0;
				break;
				
				case 5: //z up
					array[x][y][z-speed].contain = 0;
				break;
				
				case 6: //z down
					array[x][y][z+speed].contain = 0;
				break;
				
				case 0: //none
					array[x][y][z].contain = 0;
				break;
			}	
		}
		
		private int collide(int direction, int speed, int id)
		{
			switch(direction)
			{
				case 2: //up
					if (y-speed < 0)
					{
						return 2;
					}
					else
					{
						if ( array[x][y-speed][z].contain == id)
						{
							return 1;
						}
					}
				break;
				
				case 4: //down 
					if (y+speed > length-1)
					{
						return 2;
					}
					else
					{
						if (array[x][y+speed][z].contain == id)
						{
							return 1;
						}
					}
				break;
								
				case 3: //left
					if (x-speed < 0)
					{
						return 2;
					}
					else
					{
						if (array[x-speed][y][z].contain == id)
						{
							return 1;
						}
					}
				break;
				
				case 1: //right
					if (x+speed > length-1)
					{
						return 2;
					}
					else
					{
						if (array[x+speed][y][z].contain == id)
						{
							return 1;
						}
					}
				break;
				
				case 5: //z up
					if (z-speed < 0)
					{
						return 2;
					}
					else
					{
						if (array[x][y][z-speed].contain == id)
						{
							return 1;
						}
					}
				break;
				
				case 6: //z down
					if (z+speed > length_z-1)
					{
						return 2;
					}
					else
					{
						if (array[x][y][z+speed].contain == id)
						{
							return 1;
						}
					}
				break;
				
				case 0: //none
					if (array[x][y][z].contain == id)
					{
						return 1;
					}
				break;
			}	
			return 0;
		}
	}
	
	public class Camera
	{
		public int x;
		public int x_rs;
		public int y;
		public int y_rs;
		public int z;
		public int z_rs;
		public int angle;
		public Player player;
		public int drawPadding;
		
		public Camera(int _drawPadding)
		{
			x = 8;
			x_rs = 6;
			y = 8;
			y_rs = 6;
			z = 8;
			z_rs = 6;
			angle = 0;
			drawPadding = _drawPadding;
		}
		
		public void follow(Player _player)
		{
			
			int pangleX = 0;
			int pangleY = 0;
			int pangleZ = 0;
			switch (angle)
			{
				case 0:
					
				pangleX = 1;
				pangleY = 1;
				pangleZ = -z_rs;
				
				break;
				
				case 1:
					
				pangleX = 1;
				pangleY = -y_rs;
				pangleZ = 1;
				
				break;
					
				case 2:
					
				pangleX = -x_rs;
				pangleY = 1;
				pangleZ = 1;
				
				break;
			}
			
			if (_player.x < x_rs+pangleX)
			{
			x = x_rs+pangleX;
			}
			else
			{
				if (_player.x > length-(x_rs+pangleX))
				{
				x = length-(x_rs);
				}
				else
				{
					if (pangleX > 0)
					{
					x = _player.x+1;
					}
					else
					{
					x = _player.x;
					}
				}
			}
			
			if (_player.y < y_rs+pangleY)
			{
			y = y_rs+pangleY;
			}
			else
			{
				if (_player.y > length-(y_rs+pangleY))
				{
				y = length-(y_rs);
				}
				else
				{
					if (pangleY > 0)
					{
					y = _player.y+1;
					}
					else
					{
					y = _player.y;
					}
				}
			}
			
			if (_player.z < z_rs+pangleZ)
			{
			z = z_rs+pangleZ;
			}
			else
			{
				if (_player.z > length_z-(z_rs+pangleZ))
				{
				z = length_z-(z_rs);
				}
				else
				{
					if (pangleZ > 0)
					{
					z = _player.z+1;
					}
					else
					{
					z = _player.z;
					}
				}
			}
		
		}
		
		public int calculateRelativeAngle(int _angle)
		{
			int angle_ = 0;
			
			switch (angle)
			{
				case 0:
					
					angle_ = _angle;
					
				break;
				
				case 1:
					
					switch (_angle)
					{
						
						case 2: //w
						angle_ = 5;	
						break;
						
						case 4: //s
						angle_ = 6;	
						break;
						
						case 1: //d
						angle_ = 1;	
						break;
						
						case 3: //a
						angle_ = 3;	
						break;
						
						case 5: //q
						angle_ = 2;	
						break;
						
						case 6: //e
						angle_ = 4;	
						break;
					}
				break;
					
				case 2:
					
					switch (_angle)
					{
						case 1:
						angle_ = 6;	
						break;
						
						case 2:
						angle_ = 2;	
						break;
						
						case 3:
						angle_ = 5;	
						break;
						
						case 4:
						angle_ = 4;	
						break;
						
						case 5:
						angle_ = 3;	
						break;
						
						case 6:
						angle_ = 1;	
						break;
					}
					
				break;
			}
			
			return angle_;
		}
		
		private void movement(int key)
		{
			switch(key)
			{
				case KeyEvent.VK_W:
					
					if (y-y_rs-1 > 0)
					{
					y -= 1;	
					}
					else
					{
					y = y_rs+1;
					}
					
				break;
				
				case KeyEvent.VK_S:
					
					if (y+y_rs < length)
					{				
					y += 1;	
					}		
					else
					{
					y = length-y_rs;
					}
					
				break;
								
				case KeyEvent.VK_A:
					
					if (x-x_rs-1 > 0)
					{
					x -= 1;	
					}
					else
					{
					x = x_rs+1;
					}
					
				break;
				
				case KeyEvent.VK_D:
					
					if (x+x_rs < length)
					{
					x += 1;	
					}
					else
					{
					x = length-x_rs;
					}
					
				break;
				
				case KeyEvent.VK_Q:
					
					if (z-z_rs-1 > 0)
					{
					z -= 1;	
					}
					else
					{
					z = z_rs+1;
					}
					
				break;
				
				case KeyEvent.VK_E:
					
					if (z+z_rs < length)
					{
					z += 1;	
					}
					else
					{
					z = length-z_rs;
					}
					
				break;
			}	
		}
	}
	
	public Map(int _length,int _length_z,int _screen_px,int _screen_py,int _item_width,int generatorid)
	{
		length = _length;
		length_z = _length_z;
		item_width = _item_width;
		screen_px = _screen_px;
		screen_py = _screen_py;
		array = new Item[length][length][length_z];
		ticktime = 0;
		fulltick = 0;
		tick = 0;
		maxticktime = 1000;
		player1 = new Player(length-2,length-2,length_z-2);
		player =  new Player();
		if (generatorid == 1)
		{
			for (int i = 0; i < length; i++)
			{
				for (int i1 = 0; i1 < length; i1++)
				{
					for (int i2 = 0; i2 < length_z; i2++)
					{
					Item item = new Item();
						int random = (int)(Math.random() * 100 + 1);
						
						if (random > 50)
						{
							if (random > 65)
							{
								item.contain = 2;
							}
							else
							{
								random = (int)(Math.random() * 100 + 1);
								
								if (random > 60)
								{
								item.contain = 8;
								}
								else
								{
								item.contain = 1;
								}
							}
						}
						else
						{
							item.contain = 0;
						}
					array[i][i1][i2] = item;
					System.out.println(array[i][i1][i2].contain);
					}
				}
			}
		}
		else
		{
			for (int i = 0; i < length; i++)
			{
				for (int i1 = 0; i1 < length; i1++)
				{
					for (int i2 = 0; i2 < length_z; i2++)
					{
					Item item = new Item();
					
					int random = (int)(Math.random() * 100 + 1);
					
					item.contain = 2;
					
					if (i % 2 == 0 && i1 % 2 == 0)
					{
						if (random > 60)
						{
						item.contain = 8;
						}
						else
						{
						item.contain = 1;
						}
					}
					
					if (i == 1 && i1 == 1 && i2 == 1)
					{
						item.contain = 0;
					}
					
					if (i == length-2 && i1 == length-2 && i2 == length_z-2)
					{
						item.contain = 0;
					}
					
					if (i1 == 1 || i1 == length-2)
					{
						item.contain = 0;
					}
					
					if (i == 1 || i == length-2)
					{
						item.contain = 0;
					}

					
					if (i == 0 || i == length-1)
					{
						if (random > 60)
						{
						item.contain = 8;
						}
						else
						{
						item.contain = 1;
						}
					}
					
					if (i1 == 0 || i1 == length-1)
					{
						if (random > 60)
						{
						item.contain = 8;
						}
						else
						{
						item.contain = 1;
						}
					}
					
					if (i2 == 0 || i2 == length_z-1)
					{
						if (random > 60)
						{
						item.contain = 8;
						}
						else
						{
						item.contain = 1;
						}
					}
					
					
					
					array[i][i1][i2] = item;
					System.out.println(array[i][i1][i2].contain);
					}
				}
			}
		}
	}
	
	private void itemMoveTick()
	{
		for (int i = 0; i < length; i++)
		{
			for (int i1 = 0; i1 < length; i1++)
			{
				for (int i2 = 0; i2 < length_z; i2++)
				{
					if (array[i][i1][i2].hasbomb == true)
					{
						array[i][i1][i2].bomb.explode();
					}
					
					if (array[i][i1][i2].planted > 0)
					{
						if (fulltick-array[i][i1][i2].planted >= 8)
						{
							array[i][i1][i2].contain = 0;
						}
					}
				}
			}
		}
	}
	
	public void drawDebug(Graphics g)
	{
		g.drawString("tick: "+String.valueOf(tick),200-30, 100);
		g.drawString("CameraAngle: "+String.valueOf(player.camera.angle),200-30, 120);
		g.drawString("Camera: "+String.valueOf(player.camera.x)+";"+String.valueOf(player.camera.y)+";"+String.valueOf(player.camera.z),screen_px-30, 60);
		g.drawString("Player: "+String.valueOf(player.x)+";"+String.valueOf(player.y)+";"+String.valueOf(player.z),screen_px-30, 80);
		g.drawString("Health "+String.valueOf(player.health),screen_px+60, 60);
		
		g.drawString("Player: "+String.valueOf(player1.x)+";"+String.valueOf(player1.y)+";"+String.valueOf(player1.z),screen_px-30+800, 80);
		g.drawString("Health "+String.valueOf(player1.health),screen_px+800, 60);
	}
	
	public void drawMapOrder(Graphics g, Texture SpriteSheet,Camera camera)
	{
		
		int camX = camera.x;
		int camY = camera.y;
		int camX_rs = camera.x_rs;
		int camY_rs = camera.y_rs;
		int[] cell;
		cell = new int[3];
		cell[0] = -1;
		cell[1] = -2;
		cell[2] = camera.z;
		
		
		int[] cellR;
		cellR = new int[3];
		cellR[0] = 0;
		cellR[1] = 0;
		cellR[2] = 0;
		
		switch (camera.angle)
		{
			case 0:
				camX = camera.x;
				camY = camera.y;
				camX_rs = camera.x_rs;
				camY_rs = camera.y_rs;
				cell[0] = -1;
				cell[1] = -2;
				cell[2] = camera.z;
				
			break;
			
			case 1:
				camX = camera.x;
				camY = camera.z;
				camX_rs = camera.x_rs;
				camY_rs = camera.z_rs;
				cell[0] = -1;
				cell[1] = camera.y;
				cell[2] = -2;
			break;
			
			case 2:
				camX = camera.z;
				camY = camera.y;
				camX_rs = camera.z_rs;
				camY_rs = camera.y_rs;
				cell[0] = camera.x;
				cell[1] = -2;
				cell[2] = -1;
			break;
			
			}
		
		int iterator;
		int iterator1;
		
		for (int i = camX-camX_rs-1; i < camX+camX_rs; i++)
		{
			for (int i1 = camY-camY_rs-1; i1 < camY+camY_rs; i1++)
			{
				
				cellR = cellSet(i,i1,cell);
				drawMap(g,SpriteSheet,cellR[0],cellR[1],cellR[2],i,i1,camX,camY,camX_rs,camY_rs,camera);

			}
			
		}
	}
	
	private int[] cellSet(int iterator,int iterator1,int[] _cell)
	{
		int[] cell_;
		cell_ = new int[3];
		
		for (int i2 = 0; i2 < 3; i2++)
		{
			if (_cell[i2] == -1)
			{
				cell_[i2] = iterator;
			}
			else
			{
				if (_cell[i2] == -2)
				{
					cell_[i2] = iterator1;
				}
				else
				{
					cell_[i2] = _cell[i2];
				}
			}
		}
		return cell_;
	}
	
	private void drawMap(Graphics g, Texture SpriteSheet,int cellX,int cellY, int cellZ,int cam_i,int cam_i1, int camX, int camY, int camX_rs, int camY_rs,Camera camera)
	{
		double item_width_c = Math.sqrt(Math.pow(item_width,2)+Math.pow(item_width,2))+2;
		int padding_camera_x = cam_i-(camX-camX_rs);
		int padding_camera_y = cam_i1-(camY-camY_rs);

		if (array[cellX][cellY][cellZ].hasbomb == true)
		{
			drawItemTexture(g,screen_px+padding_camera_x*((int) item_width_c)+camera.drawPadding,screen_py+padding_camera_y *((int) item_width_c),5,SpriteSheet,1f);
		}
		
		if (cellX == player.x && cellY == player.y && cellZ == player.z)
		{	
			if (player.alive == true)
			{
			drawItemTexture(g,screen_px+padding_camera_x*((int) item_width_c)+camera.drawPadding,screen_py+padding_camera_y *((int) item_width_c),9,SpriteSheet,1f);
			}
		}
		if (cellX == player1.x && cellY == player1.y && cellZ == player1.z)
		{
			if (player1.alive == true)
			{
			drawItemTexture(g,screen_px+padding_camera_x*((int) item_width_c)+camera.drawPadding,screen_py+padding_camera_y *((int) item_width_c),9,SpriteSheet,1f);
			}
		}
		
		drawItemTexture(g,screen_px+padding_camera_x*((int) item_width_c)+camera.drawPadding,screen_py+padding_camera_y *((int) item_width_c),array[cellX][cellY][cellZ].contain,SpriteSheet,1f);
	}
	
	public void drawMapAlpha(Graphics g, Texture SpriteSheet, Camera camera)
	{
		for (int i2 = -1; i2 <= 1; i2++)
		{
			for (int i = camera.x-camera.x_rs-1; i < camera.x+camera.x_rs; i++)
			{
				for (int i1 = camera.y-camera.y_rs-1; i1 < camera.y+camera.y_rs; i1++)
				{
					double item_width_c = Math.sqrt(Math.pow(item_width,2)+Math.pow(item_width,2))+2;
					float padding_camera_x = i-(camera.x-camera.x_rs);
					float padding_camera_y = i1-(camera.y-camera.y_rs);
					
					float alpha = 1f;
					int padding_camera_z = 1*i2;
					
					if (i2 != 0)
					{
						padding_camera_x = padding_camera_x+padding_camera_z/1.5f;
						padding_camera_y = padding_camera_y+padding_camera_z/1.5f;
						alpha = 0.5f;
					}
					
					if (array[i][i1][camera.z+i2].hasbomb == true)
					{
						drawItemTexture(g,screen_px+(int)(padding_camera_x*item_width_c),screen_py+(int)(padding_camera_y * item_width_c),5,SpriteSheet,alpha);
					}
					drawItemTexture(g,screen_px+(int)(padding_camera_x*item_width_c),screen_py+(int)(padding_camera_y * item_width_c),array[i][i1][camera.z+i2].contain,SpriteSheet,alpha);
				}
				
			}
		}
	}
	
	public void tickMove()
	{
		if (ticktime+16 < maxticktime)
		{
			ticktime = ticktime+16;
			tick += (float)16/maxticktime;
		}
		else
		{
			ticktime -= maxticktime;
			fulltick += 1;
			itemMoveTick();
		}
		
	}
	
	private void drawItem(Graphics g, int x, int y, boolean top)
	{
		double x_calc_1;
		double y_calc_1;
		int angle = 4;
		
		if (top == true)
		{
			g.setColor(Color.RED);
		x_calc_1 = x+Math.sin(Math.toRadians((360/angle)+45))*item_width;
		y_calc_1 = y+Math.cos(Math.toRadians((360/angle)+45))*item_width;
		}
		else
		{
			g.setColor(Color.GREEN);
		x_calc_1 = x+Math.sin(Math.toRadians((360/angle*2)+45))*item_width;
		y_calc_1 = y+Math.cos(Math.toRadians((360/angle*2)+45))*item_width;
		}
		
		for (int i = 2; i <= angle+1; i++)
		{
			double x_calc = x+Math.sin(Math.toRadians(360/angle*i+45))*item_width;
			double y_calc = y+Math.cos(Math.toRadians(360/angle*i+45))*item_width;
			g.drawLine((int) x_calc,(int) y_calc,(int) x_calc_1,(int) y_calc_1);
			x_calc_1 = x_calc;
			y_calc_1 = y_calc;
		}
	}
	
	private void drawItemFill(Graphics g, int x, int y, boolean fill)
	{
		int item_width_c = (int) Math.sqrt(Math.pow(item_width,2)+Math.pow(item_width,2))+2;

		//g.setColor(Color.RED);
		if (fill == true)
		{
		g.fillRect(x-item_width_c/2,y-item_width_c/2,item_width_c,item_width_c);
		}
		else
		{
		g.drawRect(x-item_width_c/2,y-item_width_c/2,item_width_c,item_width_c);
		}
	}
	
	private void drawItemTexture(Graphics g, int x, int y, int id, Texture texture, float alpha)
	{
		int item_width_c = (int) Math.sqrt(Math.pow(item_width,2)+Math.pow(item_width,2))+2;

		
		
		Composite comp = AlphaComposite.getInstance(AlphaComposite.SRC_OVER , alpha );
		
		//AlphaComposite alcom = AlphaComposite.getInstance(AlphaComposite.CLEAR, alpha);
        ((Graphics2D) g).setComposite(comp);
       
		if (id != 0)
		{
			
			 g.drawImage(texture.SpriteSheet[id],x-item_width_c/2,y-item_width_c/2,item_width_c,item_width_c,null);
		
		}

		
	}
	
}
