import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Game 
{
	public Map map;
	public Texture texture = new Texture();
	public int mode = 1;
	public boolean serverState = false;
	
	public Game()
	{
		map = new Map(50,50,200,200,32,0);
		
	}
	
	public void draw(Graphics g)
	{
		map.drawDebug(g);
		
		if (mode == 0)
		{
		map.drawMapAlpha(g,texture,map.player.camera);
		}
		else
		{
		map.drawMapOrder(g, texture,map.player.camera);
		map.drawMapOrder(g, texture,map.player1.camera);
		}
		
		map.player.draw(g,texture);
		//map.player1.draw(g,texture);
	}
	
	public void keyinput(int key,boolean released,boolean listener,int _player)
	{
		if (listener == true)
		{
			//map.player.movinglistener(key,true);
			//map.camera.movement(key);
			switch(key)
			{
				case KeyEvent.VK_C:
					if (mode == 0)
					{
						mode = 1;
					}
					else
					{
						mode = 0;
					}
				break;
			}
		}
		else
		{
			if (_player == 1)
			{
				if (map.player1.alive == true)
				{
				map.player1.moving(key,released,true);
				}
			}
			else
			{
				if (map.player.alive == true)
				{
			
				map.player.moving(key,released,true);
				}
			}
			
			
		}
	}
	
	public void restart(int generator)
	{
		map = new Map(21,21,200,200,32,generator);
		
	}
	
	public void tickMove()
	{
		map.tickMove();
		if (map.player.alive == true)
		{
			map.player.collision();
			map.player.move(true);
		}
		
		if (map.player1.alive == true)
		{
		map.player1.collision();
		map.player1.move(true);
		}
	}
	
	
	
	
}
